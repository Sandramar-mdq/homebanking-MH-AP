package com.mindhub.homebanking.models;

public enum TransactionType {
    CREDITO,
    DEBITO
}
